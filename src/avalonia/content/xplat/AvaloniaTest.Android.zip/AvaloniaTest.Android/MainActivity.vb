﻿Imports Android.App
Imports Android.Content.PM
Imports Avalonia
Imports Avalonia.Android
Imports Avalonia.ReactiveUI

Namespace Android

  <Activity(Label:="AvaloniaTest.Android", 
            Theme:="@style/MyTheme.NoActionBar", 
            Icon:="@drawable/icon", 
            MainLauncher:=True, 
            ConfigurationChanges:=ConfigChanges.Orientation Or 
                                  ConfigChanges.ScreenSize Or 
                                  ConfigChanges.UiMode)>
  Public Class MainActivity
    Inherits AvaloniaMainActivity(Of App)

    Protected Overrides Function CustomizeAppBuilder(builder As AppBuilder) As AppBuilder
      Return MyBase.CustomizeAppBuilder(builder).WithInterFont.UseReactiveUI()
    End Function

  End Class

End Namespace